============================================================

Official website: https://cleveraddon.com/
Demo: https://codo.zootemplate.com/
Support Center: https://support.cleversoft.co/client/view_knowledge/28
Online Documentation https://doc.cleveraddon.com/clever-woocommerce-ajax-product-filter/

============================================================


CHANGE LOG 

## Version 1.0.0 released Oct 20, 2021

- Initial Release!

We have released the Clever WooCommerce Ajax Product Filter plugin. It's is fresh version (rebrand) and named cw-ajax-product-filter. 

So if you're using the clever-layered-navigation plugin, then please disable/remove it. And install the new version cw-ajax-product-filter plugin.
